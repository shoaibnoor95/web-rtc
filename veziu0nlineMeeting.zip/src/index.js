import React from 'react'
import { render } from 'react-dom'
import { Provider } from 'react-redux'
import store from './store';
import { Switch, Route, Router } from 'react-router-dom';
import Home from './containers/HomePage'
import Room from './containers/RoomPage'
import NotFound from './components/NotFound'
import './app.css'
import history from './history'

render(
	<Provider store={store}>
		<Router history={history}>
			<div>
				<Switch>
					<Route exact path="/" component={Home} />
					<Route path="/r/:room" component={Room} />
					<Route path="*" component={NotFound} />
				</Switch>
			</div>
		</Router>
	</Provider>,
	document.getElementById('app')
);
