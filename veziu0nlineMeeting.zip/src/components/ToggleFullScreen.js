const el = document.documentElement;
// const el = document.getElementById('test');
document.fullscreenEnabled = document.fullscreenEnabled ||
  document.webkitFullscreenEnabled ||
  document.mozFullScreenEnabled ||
  document.msFullscreenEnabled;
document.exitFullscreen = document.exitFullscreen ||
  document.webkitExitFullscreen ||
  document.mozCancelFullScreen ||
  document.msExitFullscreen;
if (el) {
  el.requestFullscreen = el.requestFullscreen ||
    el.webkitRequestFullscreen ||
    el.mozRequestFullScreen ||
    el.msRequestFullScreen;
}
const ToggleFullScreen = () => {
  // full-screen available?
  if (document.fullscreenEnabled) {
    // are we full-screen?
    document.fullscreenElement ||
      document.webkitFullscreenElement ||
      document.mozFullScreenElement ||
      document.msFullscreenElement ? document.exitFullscreen() : el.requestFullscreen();
  }
};
export default ToggleFullScreen;
