import React from 'react';
import './style.css'

class PublicChatBoat extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            message: "",
            publicMessage: []
        }
    }
    componentDidMount() {
        this.props.socket.on('receiveMessage', this.receiveMessage)
    }
    receiveMessage = (message) => {
        console.log(message, 'public message')
        let publicMessage = this.state.publicMessage
        message.me = false
        publicMessage.push(message)
        this.setState({ publicMessage })
        
    }
    sentMessage() {
        const mess = this.state.message
        if (mess !== "" && mess !== " ") {
            let obj = {
                message: mess,
                time: new Date(),
                userID: "123",
                userName: "testing",
                me: true
            }
            this.setState({
                publicMessage: this.state.publicMessage.concat(obj),
                message: ""
            })
            // obj.me=false
            this.props.socket.emit('sendMessage', obj)
            
        } else {
            console.log("empty message")
        }
    }
    render() {
        let PublicMessageData;
        if (this.state.publicMessage.length > 0) {
            const messages = this.state.publicMessage;
            PublicMessageData = messages.map((v, i) => {
                return (
                    <div key={i} >
                        {(v.me) ? (
                            <div className="message-item" >
                                <div className="mess-left" >
                                    <div style={{ backgroundColor: "#2c2c2c" }} className="message-left-box tri-right right-in">
                                        <div className="message">
                                            <p style={{ color: "#fff" }}>{v.message}</p>
                                        </div>
                                    </div>
                                </div>
                                <div className="prof-right">
                                    <div className="profile" user-title={v.userName}></div>
                                    {/* <span style={{fontSize: "0.3em"}}>{v.userName}</span> */}
                                </div>
                            </div>
                        ) : (
                            <div className="message-item">
                                <div className="profile" user-title={v.userName}></div>
                                <div className="message-right-box tri-right left-top">
                                    <div className="message">
                                        <p>{v.message}</p>
                                    </div>
                                    {/* <div className="sent-time">
                                            <span>{v.time.getHours()}:{v.time.getMinutes()}:{v.time.getSeconds()}</span>
                                    </div> */}
                                </div>
                            </div>
                        )}
                    </div>
                )
            })
        }
        return (
            <div className="public-chat">
                <div className="heding-p">
                    <div className="title-box" >
                        <span>Public Chat</span>
                    </div>
                    <div className="title-box-shape"></div>
                </div>
                <div id="data" style={{ overflow: 'auto', height: "calc(100vh/1.13)" }} >
                    {PublicMessageData}
                </div>
                <div className="chat-input-box">
                    <div className="write">
                        <input className="mess" value={this.state.message} onChange={(text) => this.setState({ message: text.target.value })} type="text" placeholder="Abc There..." />
                    </div>
                    <div className="sent-box">
                        <button onClick={this.sentMessage.bind(this)} className="sent">
                            <span>
                                Sent
                            </span>
                        </button>
                    </div>
                </div>
            </div>
        )
    }
}

export default PublicChatBoat