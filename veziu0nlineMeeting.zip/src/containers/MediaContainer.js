

import React, { Component } from 'react';
import { PropTypes } from 'prop-types';

class MediaBridge extends Component {
  constructor(props) {
    super(props);
    this.state = {
      bridge: '',
      user: '',
      canvStyle: '',
      container: 'default'
    }
    this.onRemoteHangup = this.onRemoteHangup.bind(this);
    this.onMessage = this.onMessage.bind(this);
    this.sendData = this.sendData.bind(this);
    this.setupDataHandlers = this.setupDataHandlers.bind(this);
    this.setDescription = this.setDescription.bind(this);
    this.sendDescription = this.sendDescription.bind(this);
    this.hangup = this.hangup.bind(this);
    this.init = this.init.bind(this);
    this.setDescription = this.setDescription.bind(this);
  }
  handleResize() {
    let obj = {
      innerWidth: window.innerWidth,
      innerHeight: window.innerHeight
    }
    if (obj.innerWidth <= 850) {
      this.setState({
        canvStyle: 'canv-850',
        container: 'mobile-view-2'
      })
    }
  }
  componentDidMount() {
    this.props.media(this);
    this.props.getUserMedia
      .then(stream => {
        this.localVideo.srcObject = this.localStream = stream
        // console.log(stream,"[][][][][][]")
      });
    this.props.socket.on('message', this.onMessage);
    this.props.socket.on('hangup', this.onRemoteHangup);
    window.addEventListener('resize', this.handleResize())
  }
  componentWillUnmount() {
    this.props.media(null);
    if (this.localStream !== undefined) {
      this.localStream.getVideoTracks()[0].stop();
    }
    this.props.socket.emit('leave');
  }
  onRemoteHangup() {
    this.setState({ user: 'host', bridge: 'host-hangup' });
  }
  onMessage(message) {
    if (message.type === 'offer') {
      // set remote description and answer
      this.pc.setRemoteDescription(new RTCSessionDescription(message))
        .then(() => this.pc.createAnswer())
        .then(this.setDescription)
        .then(this.sendDescription)
        .catch(this.handleError); // An error occurred, so handle the failure to connect

    } else if (message.type === 'answer') {
      // set remote description
      this.pc.setRemoteDescription(new RTCSessionDescription(message));
    } else if (message.type === 'candidate') {
      // add ice candidate
      this.pc.addIceCandidate(message.candidate);
    }
  }
  sendData(msg) {
    this.dc.send(JSON.stringify(msg))
  }
  // Set up the data channel message handler
  setupDataHandlers() {
    this.dc.onmessage = e => {
      var msg = JSON.parse(e.data);
      console.log('received message over data channel:' + msg);
    };
    this.dc.onclose = () => {
      this.remoteStream.getVideoTracks()[0].stop();
      console.log('The Data Channel is Closed');
    };
  }
  setDescription(offer) {
    return this.pc.setLocalDescription(offer);
  }
  // send the offer to a server to be forwarded to the other peer
  sendDescription() {
    this.props.socket.send(this.pc.localDescription);
  }
  hangup() {
    this.setState({ user: 'guest', bridge: 'guest-hangup' });
    this.pc.close();
    this.props.socket.emit('leave');
  }
  handleError(e) {
    console.log(e);
  }
  init() {
    // wait for local media to be ready
    const attachMediaIfReady = () => {
      this.dc = this.pc.createDataChannel('chat');
      this.setupDataHandlers();
      console.log('attachMediaIfReady')
      this.pc.createOffer()
        .then(this.setDescription)
        .then(this.sendDescription)
        .catch(this.handleError); // An error occurred, so handle the failure to connect
    }
    // set up the peer connection
    // this is one of Google's public STUN servers
    // make sure your offer/answer role does not change. If user A does a SLD
    // with type=offer initially, it must do that during  the whole session
    this.pc = new RTCPeerConnection({ iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] });
    // when our browser gets a candidate, send it to the peer
    this.pc.onicecandidate = e => {
      console.log(e, 'onicecandidate');
      if (e.candidate) {
        this.props.socket.send({
          type: 'candidate',
          candidate: e.candidate,
        });
      }
    };
    // when the other side added a media stream, show it on screen
    this.pc.onaddstream = e => {
      console.log('onaddstream', e)
      this.remoteStream = e.stream;
      this.remoteVideo.srcObject = this.remoteStream = e.stream;
      this.setState({ bridge: 'established' });
    };
    this.pc.ondatachannel = e => {
      // data channel
      this.dc = e.channel;
      this.setupDataHandlers();
      this.sendData({
        peerMediaStream: {
          video: this.localStream.getVideoTracks()[0].enabled
        }
      });
      //sendData('hello');
    };
    // attach local media to the peer connection
    this.localStream.getTracks().forEach(track => this.pc.addTrack(track, this.localStream));
    // call if we were the last to connect (to increase
    // chances that everything is set up properly at both ends)
    if (this.state.user === 'host') {
      this.props.getUserMedia.then(attachMediaIfReady);
    }
  }
  render() {
    return (
      <div className={[this.state.bridge]}>
        <div className={[this.state.container]}>
          <div className={`mian-canv media-bridge`}>
            <video className="remote-video" ref={(ref) => this.remoteVideo = ref} autoPlay></video>
            <video style={{display: "none"}} className="local-video" ref={(ref) => this.localVideo = ref} autoPlay muted></video>
            <div className="video-call-banner">
              <div className="user-name">
                <span>{"salman"}</span>
              </div>
              <div className="shape"></div>
              <div className="right-mic">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 25 25">
                  <g fill="none" fillRule="evenodd">
                    <g fill="#000" fillRule="nonzero">
                      <g>
                        <g>
                          <path d="M13.902 17.083c.626 0 1.214-.168 1.764-.502.55-.334.986-.787 1.309-1.357.322-.57.483-1.18.483-1.829V6.021c0-.65-.161-1.259-.483-1.83-.323-.57-.759-1.022-1.309-1.356-.55-.335-1.138-.502-1.764-.502-.625 0-1.213.167-1.763.502-.55.334-.986.786-1.309 1.357-.322.57-.483 1.18-.483 1.829v7.374c0 .65.161 1.259.483 1.83.323.57.759 1.022 1.309 1.356.55.334 1.138.502 1.763.502zm1.167 8.584v-4.042c1.29-.177 2.48-.654 3.57-1.43 1.09-.777 1.948-1.746 2.574-2.906.645-1.22.967-2.517.967-3.894h-1.991c0 1.2-.304 2.281-.91 3.245-.57.924-1.333 1.652-2.29 2.183-.958.531-1.987.796-3.087.796s-2.128-.265-3.086-.796c-.957-.531-1.72-1.259-2.29-2.183-.606-.964-.91-2.045-.91-3.245H5.625c0 1.377.322 2.675.967 3.894.626 1.16 1.484 2.129 2.574 2.906 1.09.776 2.28 1.253 3.57 1.43v4.042h2.333z" transform="translate(-1808 -8) translate(1507) translate(301 8)" />
                        </g>
                      </g>
                    </g>
                  </g>
                </svg>
              </div>
            </div>
          </div>
        </div>

      </div>
    );
  }
}
MediaBridge.propTypes = {
  socket: PropTypes.object.isRequired,
  getUserMedia: PropTypes.object.isRequired,
  media: PropTypes.func.isRequired
}
export default MediaBridge;