import React from 'react';
import './style.css';
import { PropTypes } from 'prop-types';
import MediaContainer from '../../containers/MediaContainer'
import store from '../../store'
import { connect } from 'react-redux'

class UsersView extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            users: [
                { name: "salman" },
                { name: "maaz" },
                { name: "sohaib" },
                { name: "majid" }
            ]
        }
    }
    componentDidMount() {
        // this.props.media(this);
        this.props.getUserMedia
          .then(stream => {
            this.localVideo.srcObject = this.localStream = stream
          });
        // this.props.socket.on('message', this.onMessage);
        // this.props.socket.on('hangup', this.onRemoteHangup);
      }
    render() {
        let AllUsers
        if (this.state.users.length > 0) {
            AllUsers = this.state.users.map((v, i) => {
                return (
                    <div key={i} className="user-online">
                        <div className="profile"></div>
                        <div className="user-title">
                            <span>{v.name}</span>
                        </div>
                        <div className="user-option">
                            <button>
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24">
                                    <g fill="none" fillRule="evenodd">
                                        <g fill="#b0b0b0" fillRule="nonzero">
                                            <g>
                                                <g>
                                                    <path d="M13.902 17.083c.626 0 1.214-.168 1.764-.502.55-.334.986-.787 1.309-1.357.322-.57.483-1.18.483-1.829V6.021c0-.65-.161-1.259-.483-1.83-.323-.57-.759-1.022-1.309-1.356-.55-.335-1.138-.502-1.764-.502-.625 0-1.213.167-1.763.502-.55.334-.986.786-1.309 1.357-.322.57-.483 1.18-.483 1.829v7.374c0 .65.161 1.259.483 1.83.323.57.759 1.022 1.309 1.356.55.334 1.138.502 1.763.502zm1.167 8.584v-4.042c1.29-.177 2.48-.654 3.57-1.43 1.09-.777 1.948-1.746 2.574-2.906.645-1.22.967-2.517.967-3.894h-1.991c0 1.2-.304 2.281-.91 3.245-.57.924-1.333 1.652-2.29 2.183-.958.531-1.987.796-3.087.796s-2.128-.265-3.086-.796c-.957-.531-1.72-1.259-2.29-2.183-.606-.964-.91-2.045-.91-3.245H5.625c0 1.377.322 2.675.967 3.894.626 1.16 1.484 2.129 2.574 2.906 1.09.776 2.28 1.253 3.57 1.43v4.042h2.333z" transform="translate(-1808 -8) translate(1507) translate(301 8)" />
                                                </g>
                                            </g>
                                        </g>
                                    </g>
                                </svg>
                            </button>
                            <button>
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24">
                                    <defs>
                                        <filter id="v81w57vnva">
                                            <feColorMatrix in="SourceGraphic" values="0 0 0 0 0.431373 0 0 0 0 0.431373 0 0 0 0 0.431373 0 0 0 1.000000 0" />
                                        </filter>
                                    </defs>
                                    <g fill="none" fillRule="evenodd">
                                        <g>
                                            <g>
                                                <g filter="url(#v81w57vnva)" transform="translate(-1779 -307) translate(1506 237) translate(1 45)">
                                                    <g>
                                                        <path d="M0 0L24 0 24 24 0 24z" transform="translate(272 25)" />
                                                        <path fill="#000" fillRule="nonzero" d="M17 10.5L17 6 3 6 3 18 17 18 17 13.5 21 17.5 21 6.5z" transform="translate(272 25)" />
                                                    </g>
                                                </g>
                                            </g>
                                        </g>
                                    </g>
                                </svg>

                            </button>
                        </div>
                    </div>
                )
            })
        }
        
        return (
            <div className="public-users">
                <div className="user-me">
                    <div className="profile-camera">
                        <video  ref={(ref) => this.localVideo = ref} autoPlay muted></video>
                        {/* <img src={ProfileImg} alt="profile/vedios" /> */}
                    </div>
                    <div className="user-info-box">
                        <div className="user-name">
                            <span>{"salman"}</span>
                        </div>
                        <div className="shape"></div>
                        <div className="right-mic">
                            {/* mic replacement */}
                        </div>
                    </div>
                </div>
                <div className="all-users">
                    {AllUsers}
                </div>
            </div>
        )
    }
}

const mapStateToProps = store => ({ video: store.video, audio: store.audio });
const mapDispatchToProps = dispatch => (
    {
        setVideo: boo => store.dispatch({ type: 'SET_VIDEO', video: boo }),
        setAudio: boo => store.dispatch({ type: 'SET_AUDIO', audio: boo })
    }
);

UsersView.propTypes = {
    // socket: PropTypes.object.isRequired,
    getUserMedia: PropTypes.object.isRequired,
    // audio: PropTypes.bool.isRequired,
    // video: PropTypes.bool.isRequired,
    // setVideo: PropTypes.func.isRequired,
    // setAudio: PropTypes.func.isRequired,
    media: PropTypes.instanceOf(MediaContainer)
};
export default connect(mapStateToProps, mapDispatchToProps)(UsersView);
