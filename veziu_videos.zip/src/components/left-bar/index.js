import React from 'react';
import { PropTypes } from 'prop-types';
import ToggleFullScreen from '../ToggleFullScreen';
import MediaContainer from '../../containers/MediaContainer'
import PublicChatBoat from '../public-chat';
import UsersView from '../users-view'
import store from '../../store'
import { connect } from 'react-redux'


class LeftBar extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            publicChat: false,
            usersView: false,
            sid: '',
            message: '',
            audio: true,
            video: true
        }
        this.handleInvitation = this.handleInvitation.bind(this);
        this.handleHangup = this.handleHangup.bind(this);
        this.handleInput = this.handleInput.bind(this);
        this.toggleVideo = this.toggleVideo.bind(this);
        this.toggleAudio = this.toggleAudio.bind(this);
        this.send = this.send.bind(this);
    }
    hideAuth() {
        this.props.media.setState({ bridge: 'connecting' });
    }
    full() {
        this.props.media.setState({ bridge: 'full' });
    }
    componentDidMount() {
        // const socket = this.props.socket;
        // console.log('props', this.props)
        // this.setState({ video: this.props.video, audio: this.props.audio });

        // socket.on('create', () =>
        //     this.props.media.setState({ user: 'host', bridge: 'create' }));
        // socket.on('full', this.full);
        // socket.on('bridge', role => this.props.media.init());
        // socket.on('join', () =>
        //     this.props.media.setState({ user: 'guest', bridge: 'join' }));
        // socket.on('approve', ({ message, sid }) => {
        //     this.props.media.setState({ bridge: 'approve' });
        //     this.setState({ message, sid });
        // });
        // socket.emit('find');
        this.props.getUserMedia
            .then(stream => {
                this.localStream = stream;
                this.localStream.getVideoTracks()[0].enabled = this.state.video;
                this.localStream.getAudioTracks()[0].enabled = this.state.audio;
            });
    }
    handleInput(e) {
        this.setState({ [e.target.dataset.ref]: e.target.value });
    }
    send(e) {
        e.preventDefault();
        this.props.socket.emit('auth', this.state);
        this.hideAuth();
    }
    handleInvitation(e) {
        e.preventDefault();
        console.log(e.target.dataset.ref + "ssss")
        this.props.socket.emit([e.target.dataset.ref], this.state.sid);
        this.hideAuth();
    }
    getContent(content) {
        return { __html: (new Remarkable()).render(content) };
    }
    toggleVideo() {
        const video = this.localStream.getVideoTracks()[0].enabled = !this.state.video;
        this.setState({ video: video });
        this.props.setVideo(video);
    }
    toggleAudio() {
        const audio = this.localStream.getAudioTracks()[0].enabled = !this.state.audio;
        this.setState({ audio: audio });
        this.props.setAudio(audio);
    }
    handleHangup() {
        this.props.media.hangup();
    }
    render() {
        return (
            <div className="right-bar">
                <div className="call-action">
                    <button onClick={this.toggleAudio} className={'audio-button-' + this.props.audio}>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50" className="svg">
                            <path className="on" d="M38 22h-3.4c0 1.49-.31 2.87-.87 4.1l2.46 2.46C37.33 26.61 38 24.38 38 22zm-8.03.33c0-.11.03-.22.03-.33V10c0-3.32-2.69-6-6-6s-6 2.68-6 6v.37l11.97 11.96zM8.55 6L6 8.55l12.02 12.02v1.44c0 3.31 2.67 6 5.98 6 .45 0 .88-.06 1.3-.15l3.32 3.32c-1.43.66-3 1.03-4.62 1.03-5.52 0-10.6-4.2-10.6-10.2H10c0 6.83 5.44 12.47 12 13.44V42h4v-6.56c1.81-.27 3.53-.9 5.08-1.81L39.45 42 42 39.46 8.55 6z" fill="white"></path>
                            <path className="off" d="M24 28c3.31 0 5.98-2.69 5.98-6L30 10c0-3.32-2.68-6-6-6-3.31 0-6 2.68-6 6v12c0 3.31 2.69 6 6 6zm10.6-6c0 6-5.07 10.2-10.6 10.2-5.52 0-10.6-4.2-10.6-10.2H10c0 6.83 5.44 12.47 12 13.44V42h4v-6.56c6.56-.97 12-6.61 12-13.44h-3.4z" fill="white"></path>
                        </svg>
                    </button>
                    <button onClick={this.toggleVideo} className={'video-button-' + this.props.video}>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50" className="svg">
                            <path className="on" d="M40 8H15.64l8 8H28v4.36l1.13 1.13L36 16v12.36l7.97 7.97L44 36V12c0-2.21-1.79-4-4-4zM4.55 2L2 4.55l4.01 4.01C4.81 9.24 4 10.52 4 12v24c0 2.21 1.79 4 4 4h29.45l4 4L44 41.46 4.55 2zM12 16h1.45L28 30.55V32H12V16z" fill="white"></path>
                            <path className="off" d="M40 8H8c-2.21 0-4 1.79-4 4v24c0 2.21 1.79 4 4 4h32c2.21 0 4-1.79 4-4V12c0-2.21-1.79-4-4-4zm-4 24l-8-6.4V32H12V16h16v6.4l8-6.4v16z" fill="white"></path>
                        </svg>
                    </button>
                    <button onClick={ToggleFullScreen} className="fullscreen-button">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50" className="svg">
                            <path className="on" d="M10 32h6v6h4V28H10v4zm6-16h-6v4h10V10h-4v6zm12 22h4v-6h6v-4H28v10zm4-22v-6h-4v10h10v-4h-6z" fill="white"></path>
                            <path className="off" d="M14 28h-4v10h10v-4h-6v-6zm-4-8h4v-6h6v-4H10v10zm24 14h-6v4h10V28h-4v6zm-6-24v4h6v6h4V10H28z" fill="white"></path>
                        </svg>
                    </button>
                </div>
                <div className="options">
                    <button onClick={() => {
                        this.setState({
                            publicChat: false,
                            usersView: !this.state.usersView
                        })
                    }} className="opt-btn" option-title="Public chat">
                        <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 25 24">
                            <g fill="none" fillRule="evenodd">
                                <g fill="#000" fillRule="nonzero">
                                    <g>
                                        <g>
                                            <g>
                                                <path d="M18.205 18.861c0-.655-.186-1.242-.558-1.763-.372-.521-.87-.9-1.495-1.139-.209-.089-.514-.163-.915-.223-.402-.06-.707-.134-.916-.223-.357-.09-.565-.208-.625-.357-.06-.149-.089-.372-.089-.67v-.49c0-.03.052-.105.156-.224.105-.12.157-.194.157-.223.148-.268.253-.73.312-1.384.12.03.216 0 .29-.09.075-.089.127-.238.157-.446l.089-.312c.03-.06.052-.142.067-.246.015-.104.03-.223.044-.357.015-.134 0-.246-.044-.335-.045-.09-.112-.119-.201-.09.06-.089.119-.312.178-.669.12-.744.105-1.324-.044-1.74-.179-.566-.514-1.013-1.005-1.34-.49-.328-1.034-.506-1.63-.536-.624-.03-1.204.104-1.74.402-.536.297-.908.729-1.116 1.294-.179.506-.223 1.087-.134 1.742.06.446.134.729.223.848-.208-.03-.253.283-.134.937 0 .03.022.142.067.335.045.194.104.35.179.469.074.119.17.164.29.134.06.476.119.833.178 1.071.12.298.239.506.358.625.06.06.089.134.089.223 0 .566-.015.908-.045 1.027-.06.298-.446.491-1.16.58-1.161.268-1.89.507-2.188.715-.804.565-1.205 1.384-1.205 2.455h12.41zM22 16.718c0-.893-.461-1.488-1.384-1.785-.09-.03-.23-.06-.424-.09-.193-.03-.365-.074-.513-.134-.15-.06-.268-.134-.358-.223-.03-.03-.044-.283-.044-.759.268 0 .461-.015.58-.044l.536-.134c.03-.03.074-.045.134-.045.06 0 .104-.015.134-.045.089-.03.089-.119 0-.267-.12-.179-.209-.402-.268-.67-.06-.268-.09-.491-.09-.67 0-.178.008-.431.023-.759.015-.327.022-.55.022-.67 0-.952-.297-1.606-.893-1.964-.684-.386-1.398-.431-2.142-.134-.745.298-1.146 1.102-1.206 2.411-.06 1.31-.134 2.069-.223 2.277-.12.268-.12.432 0 .491.149.06.312.12.491.179.357.06.625.089.804.089v.625c-.03.09-.268.193-.715.312-.327.09-.52.179-.58.268-.03.09-.008.15.067.179.074.03.171.044.29.044h.223c.328.06.744.283 1.25.67.417.357.655.64.715.848H22zM6.808 15.47h.013l.055-.03.036-.024L7 15.38h.045c.208-.09.52-.164.937-.223.149 0 .179-.075.09-.223-.06-.06-.15-.112-.268-.157-.12-.044-.26-.081-.425-.111-.163-.03-.275-.06-.334-.09-.15-.03-.224-.133-.224-.312v-.491c.03-.03.164-.045.402-.045.357-.06.61-.119.76-.178l.267-.134c.03-.03-.015-.164-.134-.402-.149-.387-.223-.744-.223-1.071v-.96c0-.521-.03-.915-.09-1.183-.178-1.101-.877-1.652-2.098-1.652-.803 0-1.369.268-1.696.803-.238.358-.357 1.087-.357 2.188 0 .565-.015.982-.045 1.25 0 .06-.015.141-.045.246-.03.104-.059.186-.089.245l-.178.536c.357.268.833.372 1.428.312 0 .387-.015.625-.044.715-.03.089-.134.163-.313.223-.178.06-.387.119-.625.178-.238.06-.372.09-.402.09C2.446 15.23 2 15.825 2 16.718h3.571c.06 0 .164-.163.313-.49.298-.328.655-.61 1.071-.849l-.147.09z" transform="translate(-1872 -302) translate(1847) translate(1.5 278) translate(24 24)" />
                                            </g>
                                        </g>
                                    </g>
                                </g>
                            </g>
                        </svg>
                    </button>
                    <button onClick={() => {
                        this.setState({
                            usersView: false,
                            publicChat: !this.state.publicChat
                        })
                    }} className="opt-btn" option-title="Public chat">
                        <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 25 25">
                            <g fill="none" fillRule="evenodd">
                                <g>
                                    <g>
                                        <g>
                                            <g>
                                                <g>
                                                    <path d="M0 0L24 0 24 24 0 24z" transform="translate(-1872 -374) translate(1847) translate(1.5 278) translate(0 72) translate(24 24)" />
                                                    <path fill="#000" fillRule="nonzero" d="M22 2H2.01L2 22l4-4h16V2zM6 9h12v2H6V9zm8 5H6v-2h8v2zm4-6H6V6h12v2z" transform="translate(-1872 -374) translate(1847) translate(1.5 278) translate(0 72) translate(24 24)" />
                                                </g>
                                            </g>
                                        </g>
                                    </g>
                                </g>
                            </g>
                        </svg>
                    </button>
                </div>
                <div className="settings">
                    <button onClick={this.handleHangup} className="opt-btn" option-title="Hangup">
                        <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 25 25">
                            <defs>
                                <filter id="16bg7hr4ya">
                                    <feColorMatrix in="SourceGraphic" values="0 0 0 0 0.556863 0 0 0 0 0.556863 0 0 0 0 0.556863 0 0 0 1.000000 0" />
                                </filter>
                            </defs>
                            <g fill="none" fillRule="evenodd">
                                <g>
                                    <g>
                                        <g>
                                            <g filter="url(#16bg7hr4ya)" transform="translate(-1871 -1023) translate(1847) translate(.5 855) translate(0 144)">
                                                <g>
                                                    <g fill="#000" fillRule="nonzero">
                                                        <path fill="#000" d="M17.76 20c.604 0 1.129-.222 1.573-.667.445-.444.667-.969.667-1.573V2.24c0-.604-.222-1.129-.667-1.573C18.89.222 18.364 0 17.76 0H2.24C1.618 0 1.089.222.653.667.218 1.11 0 1.636 0 2.24v4.427h2.24V2.24h15.52v15.52H2.24v-4.427H0v4.427c0 .604.218 1.129.653 1.573.436.445.965.667 1.587.667h15.52zm-8.32-4.427L15.013 10 9.44 4.427 7.867 6l2.853 2.907H0v2.186h10.72L7.867 14l1.573 1.573z" transform="translate(24 24) translate(2 2)" />
                                                    </g>
                                                </g>
                                            </g>
                                        </g>
                                    </g>
                                </g>
                            </g>
                        </svg>
                    </button>
                </div>
                {
                    this.state.publicChat ? (
                        <PublicChatBoat socket={this.props.socket} />
                    ) : null
                }
                {
                    this.state.usersView ? (
                        <UsersView getUserMedia={this.props.getUserMedia} />
                    ) : null
                }
            </div >
        )
    }
}


const mapStateToProps = store => ({ video: store.video, audio: store.audio });
const mapDispatchToProps = dispatch => (
    {
        setVideo: boo => store.dispatch({ type: 'SET_VIDEO', video: boo }),
        setAudio: boo => store.dispatch({ type: 'SET_AUDIO', audio: boo })
    }
);

LeftBar.propTypes = {
    socket: PropTypes.object.isRequired,
    getUserMedia: PropTypes.object.isRequired,
    audio: PropTypes.bool.isRequired,
    video: PropTypes.bool.isRequired,
    setVideo: PropTypes.func.isRequired,
    setAudio: PropTypes.func.isRequired,
    media: PropTypes.instanceOf(MediaContainer)
};
export default connect(mapStateToProps, mapDispatchToProps)(LeftBar);